README.md

Subpunctul 2 (Caracteristica statica)

	- Ales mai multe valori (min 8) pentru vectorul de intrari in intervalul (0...3]V
	- Variem o intrare, iar cealalta o pastram constanta (treapta)
	- Salvam vectorul iesirilor si alegem valoarea dupa ce s-a stabilizat
	- Folosim cftool pe vectorul cu intrarile U variate si vectorul Y cu iesirile stabilizate asociate