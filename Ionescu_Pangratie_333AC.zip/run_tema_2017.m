clear all;

animation_enable = 0;		% Disable animations by default and let the script take care of this
model_name = 'tema_2017';
time_step = 1;
time_count = 300;

% run('load_workspace_a');	% Incarcat variabile in workspace
% run('tema_comm_a.m');

% run('load_workspace_b');	% Incarcat variabile in workspace
% run('tema_comm_b.m');

% run('load_workspace_c');	% Incarcat variabile in workspace
% run('tema_comm_c.m');

% run('load_workspace_d');	% Incarcat variabile in workspace
% run('tema_comm_d.m');

% run('load_workspace_e');	% Incarcat variabile in workspace
% run('tema_comm_e.m');

% run('load_workspace_f');	% Incarcat variabile in workspace
% run('tema_comm_f.m');

% run('load_workspace_g');	% Incarcat variabile in workspace
% run('tema_comm_g.m');

run('load_workspace_h');	% Incarcat variabile in workspace
run('tema_comm_h.m');