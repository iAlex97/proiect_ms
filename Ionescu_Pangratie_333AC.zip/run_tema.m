clear all;

model_name = 'tema';
run('tema_comm.m');